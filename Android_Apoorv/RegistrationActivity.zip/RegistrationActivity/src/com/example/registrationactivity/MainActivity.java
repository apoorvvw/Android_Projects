package com.example.registrationactivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends ActionBarActivity 
{
	
	public static final String EXTRA_MESSAGE = "com.example.registrationactivity.MESSAGE";
	Button bLogin;
	EditText etEmail, etPassword;
	TextView tvOutcome, tv2;
	String userEmail;
	Intent intent;
	public static int a = 123;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        bLogin = (Button) findViewById(R.id.btnLogin);
        etEmail = (EditText) findViewById(R.id.loginEmail);
        etPassword = (EditText)findViewById(R.id.loginPassword);
        etEmail.setText("");
        etPassword.setText("");
        /*tvOutcome = (TextView)findViewById(R.id.outcome);
        tvOutcome.setText(" ");
        tv2 = (TextView)findViewById(R.id.textView1);
        tv2.setText("-->");*/

       //Log.
       
        
        bLogin.setOnClickListener( new View.OnClickListener() {
			
			@Override
			public void onClick(View v) 
			{
				// TODO Auto-generated method stub
				userEmail = etEmail.getText().toString();
				// tv2.append(userEmail+"-->");
				
				//tvOutcome.setText("Click Listner called");
				intent = new Intent(MainActivity.this, DisplayMessageActivity.class);//getApplicationContext()
				
				validateEmail(userEmail);
				
				startActivityForResult( intent,a);

			}

			
		});
        
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.container, new PlaceholderFragment())
                    .commit();
        }
    }
/*************************************************************************************************/
    private void validateEmail(String email) 
	{
		// TODO Auto-generated method stub
		int countAt = 0, locAt = 0, countDot = 0, locDot = 0;
		boolean result = true;
		
		//tv2.append(email);
		
		for (int i = 0; i<email.length(); i++)
		{
			//Check it it is an email id	
			char c =email.charAt(i);
			//tv2.append(" "+c);
			if (c=='@')
			{
				countAt++;
				locAt = i;
			}
			else if (c=='.')
			{
				countDot++;
				locDot = i;
			}
			/*else if ( (c < 46) || ( (c>46) && (c<64) ) )
				result = false;*/	
		}
		
		
		if ( (locDot < locAt) || ( (countAt > 1) || (countAt== 0) ) || ( (countDot > 1) || (countDot== 0) ) )
		{
			result = false;
			//tvOutcome.append("False"+" locAt="+locAt+" countAt="+countAt+" locDot="+locDot+" countDot="+countDot);		
	    }
		if(result==true)
		{
			Toast.makeText(this, "Login SuccessFul", Toast.LENGTH_SHORT).show();
			intent.putExtra(EXTRA_MESSAGE,"Logged In");
		}
		else
		{
			Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show();
			intent.putExtra(EXTRA_MESSAGE,"Invalid ID");
		}
	}
    /************************************************************************************************************/
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {

        public PlaceholderFragment() {
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_main, container, false);
            return rootView;
        }
    }

    @Override
    protected void onActivityResult(int arg0, int arg1, Intent arg2) {
    	// TODO Auto-generated method stub
    	super.onActivityResult(arg0, arg1, arg2);
    	
    	if (arg1 == a) {
			finish();
		}
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
    	// TODO Auto-generated method stub
    	return super.onKeyDown(keyCode, event);
          
    }
}
