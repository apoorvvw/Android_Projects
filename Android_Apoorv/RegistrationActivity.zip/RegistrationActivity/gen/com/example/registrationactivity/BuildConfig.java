/** Automatically generated file. DO NOT MODIFY */
package com.example.registrationactivity;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}